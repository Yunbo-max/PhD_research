We collected both datasets directly from [GRIN repository](https://github.com/Graph-Machine-Learning-Group/grin) which provides a [link](https://mega.nz/folder/qwwG3Qba#c6qFTeT7apmZKKyEunCzSg) to access them.  

If you collect the data from there, remember to feature sample the datasets as described in our technical appendix.
