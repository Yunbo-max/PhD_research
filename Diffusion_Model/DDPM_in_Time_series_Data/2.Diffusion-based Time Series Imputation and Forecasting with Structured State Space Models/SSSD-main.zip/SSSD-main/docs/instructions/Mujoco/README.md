We collected the dataset directly from [NRTSI repository](https://github.com/lupalab/NRTSI/tree/main/codes_regularly-sampled), which provides a [link](https://www.dropbox.com/s/pjccc2piis8g2fx/mujoco_train.npy?dl=0) for the train set, and another [link](https://www.dropbox.com/s/ktkswh77sueqfy8/mujoco_test.npy?dl=0) for the test set.  

Shan, Siyuan, Yang Li, and Junier B. Oliva. "Nrtsi: Non-recurrent time series imputation." arXiv preprint arXiv:2102.03340 (2021).
